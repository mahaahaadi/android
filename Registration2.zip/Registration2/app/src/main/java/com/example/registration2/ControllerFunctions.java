package com.example.registration2;

import java.util.HashMap;
import java.util.List;
import retrofit2.Call;

import retrofit2.http.POST;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;


public interface ControllerFunctions
{
    @FormUrlEncoded
    @POST("Student/getUserDetails/")
    Call<List<ResponseData>> getUserDetails(@FieldMap HashMap<String, String> hashMap);

    @FormUrlEncoded
    @POST("Student/getStudentDetails/")
    Call<List<ResponseData>> getStudentDetails(@FieldMap HashMap<String, String> hashMap);

    @FormUrlEncoded
    @POST("Student/checkLogin/")
    Call<List<ResponseData>> checkLogin(@FieldMap HashMap<String, String> hashMap);

    @FormUrlEncoded
    @POST("Student/insertUserDetails/")
    Call<List<ResponseData>> insertUserDetails(@FieldMap HashMap<String, String> hashMap);
}
