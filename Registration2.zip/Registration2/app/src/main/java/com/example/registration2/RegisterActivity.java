package com.example.registration2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends Activity
{

    EditText first_name, last_name, phone_number, email, password;
    Button register;
    String first_name_str, last_name_str, phone_number_str, email_str, password_str;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        first_name   = (EditText) findViewById(R.id.register_firstname);
        last_name    = (EditText) findViewById(R.id.register_lastname);
        phone_number = (EditText) findViewById(R.id.register_phonenumber);
        email        = (EditText) findViewById(R.id.register_email);
        password     = (EditText) findViewById(R.id.register_password);
        register     = (Button) findViewById(R.id.register_regbtn);

        register.setOnClickListener(new View.OnClickListener()
        {
            @Override

                public void onClick(View v)
                {
                first_name_str = first_name.getText().toString();
                last_name_str = last_name.getText().toString();
                phone_number_str = phone_number.getText().toString();
                email_str = email.getText().toString();
                password_str = password.getText().toString();

                try
                {
                    JSONArray jsonArray = new JSONArray();
                    JSONObject jsonObject = new JSONObject();

                    jsonObject.put("firstname", first_name_str);
                    jsonObject.put("lastname", last_name_str);
                    jsonObject.put("phonenumber", phone_number_str);
                    jsonObject.put("email", email_str);
                    jsonObject.put("password", password_str);

                    jsonArray.put(jsonObject);
                    Database_register insert_data = new Database_register(RegisterActivity.this);

                    // insert_data.insert(jsonArray);
                }

                  catch (JSONException e)
                  {
                    e.printStackTrace();
                  }


        if ( (!first_name_str.equals("")) && (!last_name_str.equals("")) && (!phone_number_str.equals("")) && (!email_str.equals("")) && (!password_str.equals("")))
        {
            if (phone_number_str.length() == 10)
            {
                if ((!TextUtils.isEmpty(email_str) && Patterns.EMAIL_ADDRESS.matcher(email_str).matches()))
                {
                    if (password_str.length() >= 8)
                    {
                        // inserting data

                        //Base URL implementation
                        ControllerFunctions service = BaseURLInstance.getRetrofitInstance(RegisterActivity.this).create(ControllerFunctions.class);
                        //post parameters
                        HashMap<String, String> params = new HashMap<>();
                        params.put("firstname", first_name_str);
                        params.put("lastname", last_name_str);
                        params.put("phone", phone_number_str);
                        params.put("email", email_str);
                        params.put("password", password_str);

                        //calling controller's functions
                        Call<List<ResponseData>> call = service.insertUserDetails(params);

                        call.enqueue(new Callback<List<ResponseData>>() {
                            @Override
                            public void onResponse(Call<List<ResponseData>> call, Response<List<ResponseData>> response) {
                                //getting server response
                                if (response.isSuccessful()) {
                                    //check response variable is true or false
                                    String strResponse = response.body().get(0).getResponse();
                                    if (strResponse.equals("true")) {
                                        Intent target = new Intent(getApplicationContext(), MainActivity.class);
                                        startActivity(target);
                                    } else {
                                        Toast.makeText(RegisterActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                                    }
                                }

                            }

                            @Override
                            public void onFailure(Call<List<ResponseData>> call, Throwable t) {
                            }
                        });
                    } else {
                        Toast.makeText(RegisterActivity.this, "Password length should be above 7", Toast.LENGTH_SHORT).show();
                    }

                }
                else
                {
                    Toast.makeText(RegisterActivity.this, "Email formate is invalid", Toast.LENGTH_SHORT).show();
                }
            }
            else
            {
                Toast.makeText(RegisterActivity.this, "Enter only 10 digit mobile number", Toast.LENGTH_SHORT).show();
            }
            //for phonenumber
        }
        else
        {
                Toast.makeText(RegisterActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
        }


            }

        });
    }
}