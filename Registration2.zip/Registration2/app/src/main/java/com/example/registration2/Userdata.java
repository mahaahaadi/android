package com.example.registration2;

public class Userdata
{
    String strfirstname, strlastname,strphonenumber,stremail,strpassword;

    public void setstrfirstname(String strfirstname)
    {
        this.strfirstname = strfirstname;
    }

    public String getstrfirstname()
    {
        return "Firstname  :  " + strfirstname;
    }

    // for lastname
    public void setstrlastname(String strlastname)
    {
        this.strlastname = strlastname;
    }

    public String getstrlastname()
    {
        return "Lastname  :  " + strlastname;
    }

    // for phonenumber
    public void setstrphonenumber(String strphonenumber)
    {
        this.strphonenumber = strphonenumber;
    }

    public String getstrphonenumber()
    {
        return "Phone         :  " + strphonenumber;
    }

    // for email
    public void setstremail(String stremail)
    {
        this.stremail = stremail;
    }

    public String getstremail()
    {
        return  "Email          :  " + stremail;
    }

    // for password
    public void setstrpassword(String strpassword)
    {
        this.strpassword = strpassword;
    }

    public String getstrpassword()
    {
        return "Password :  " + strpassword;
    }

}