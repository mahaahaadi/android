package com.example.registration2;

import java.util.ArrayList;
import android.widget.Toast;
import android.content.Context;
import android.database.Cursor;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.database.sqlite.SQLiteOpenHelper;


public class Database_register extends SQLiteOpenHelper
{
    private static final String database_name = "registration";
    String table_name = "register";
    private static final Integer database_version = 1;
    Context context;

    public Database_register(Context context)
    {
        super(context,database_name,null,database_version);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
    String create_table_query = "create table " +
    table_name + "(id int(25), firstname text(25),lastname,phonenumber int(100),email text(25),password text(25));";

    db.execSQL(create_table_query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
    /*
    * alter query
    * */
    }

    public void  insert(JsonArray jsonArray)
    {
        String insert_query = "insert into "
        + table_name +
        "(firstname,lastname,phonenumber,email,password) values(?,?,?,?,?);";

        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();

        SQLiteStatement SQLsmt = database.compileStatement(insert_query);

        try
        {
           if(jsonArray.size() > 0)
           {
               for(int i=0; i<jsonArray.size(); i++)
               {
                JsonObject jsonObject = jsonArray.get(i).getAsJsonObject();
                SQLsmt.bindString(1,jsonObject.get("first_name").getAsString());
                SQLsmt.bindString(2,jsonObject.get("last_name").getAsString());
                SQLsmt.bindString(3,jsonObject.get("phone").getAsString());
                SQLsmt.bindString(4,jsonObject.get("email").getAsString());
                SQLsmt.bindString(5,jsonObject.get("password").getAsString());
                SQLsmt.executeInsert();
                SQLsmt.clearBindings();
               }
           }
        }
        catch (Exception e)
        {

        }

        database.setTransactionSuccessful();
        database.endTransaction();
        database.close();

    }

    public void delete_data()
    {
        String delete_query = "delete from "+ table_name;
        SQLiteDatabase database = getWritableDatabase();
//        database.beginTransaction();  is not used while deleting
        database.execSQL(delete_query);
    }


    public ArrayList<Userdata> getUserdata()
    {
        ArrayList<Userdata> getUserData = new ArrayList<>();
        SQLiteDatabase database = getReadableDatabase();
        String userQuery = "SELECT firstname,lastname,phonenumber,email FROM "+ table_name;
        Cursor cursor = database.rawQuery(userQuery, null);

        if (cursor.moveToFirst())
        {
            do
            {
                Userdata userData = new Userdata();
                userData.setstrfirstname(cursor.getString(cursor.getColumnIndex("firstname")));
                userData.setstrlastname(cursor.getString(cursor.getColumnIndex("lastname")));
                userData.setstrphonenumber(cursor.getString(cursor.getColumnIndex("phonenumber")));
                userData.setstremail(cursor.getString(cursor.getColumnIndex("email")));
//                userData.setstrpassword(cursor.getString(cursor.getColumnIndex("password")));
                getUserData.add(userData);
            }

            while (cursor.moveToNext());
        }
        database.close();
        return getUserData;
    }
}
