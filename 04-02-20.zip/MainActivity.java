package com.example.registration2;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.TextView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;
import retrofit2.Callback;
import retrofit2.Response;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity
{
    String phone_str,password_str;

    EditText phone,password;
    TextView newuser;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        phone    = (EditText) findViewById(R.id.login_phonenumber);
        password = (EditText) findViewById(R.id.login_password);
        newuser  = (TextView) findViewById(R.id.login_newuser);
        login    = (Button)   findViewById(R.id.login_regbtn);

        phone_str = phone.getText().toString();
        password_str = password.getText().toString();

    newuser.setOnClickListener(new View.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            Intent register_page = new Intent(getApplicationContext(), RegisterActivity.class);
            startActivity(register_page);
        }
    });

    login.setOnClickListener(new View.OnClickListener()
    {

    @Override
    public void onClick(View v)
    {
    // TODO Auto-generated method stub
    phone_str = phone.getText().toString();
    password_str = password.getText().toString();

        if ((!phone_str.equals("")) && (!password_str.equals("")))
        {
            if (phone_str.length() == 10)
            {
                if (password_str.length() >= 8) {
                    //Base URL implementation
                    ControllerFunctions service = BaseURLInstance.getRetrofitInstance(MainActivity.this).create(ControllerFunctions.class);

                    //post parameters
                    HashMap<String, String> params = new HashMap<>();
                    params.put("phone", phone_str);
                    params.put("password", password_str);

                    //calling controller's functions
                    Call<List<ResponseData>> call = service.checkLogin(params);

                    call.enqueue(new Callback<List<ResponseData>>()
                    {
                        @Override
                        public void onResponse(Call<List<ResponseData>> call, Response<List<ResponseData>> response)
                        {
                                //getting server response
                                if (response.isSuccessful())
                                {
                                    //check response variable is true or false
                                    String strResponse = response.body().get(0).getResponse();

                                    if (strResponse.equals("true"))
                                    {

                                        SharedPreferences sharedPreferences = getSharedPreferences("hiddenfile", Context.MODE_PRIVATE);
                                        // MODE_private is for hiding the data
                                        // logindatasp is hidden file where the required data like username and passwords are stored.


                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        editor.putString("phone",phone.getText().toString());
                                        editor.putString("password",password.getText().toString());
                                        editor.commit(); //closing syntax



                                        Intent target = new Intent(getApplicationContext(), ListViewActivity.class);
                                        startActivity(target);
                                    }
                                    else
                                    {
                                        Toast.makeText(MainActivity.this, "Error in Username or Password", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }

                            @Override
                            public void onFailure(Call<List<ResponseData>> call, Throwable t)
                            {
                                Toast.makeText(MainActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                            }
                        });

                }
        //for phone number
        else
        {
            Toast.makeText(MainActivity.this, "Password length should be abouve 7", Toast.LENGTH_SHORT).show();
        }
        }
        else
        {
            Toast.makeText(MainActivity.this, "Phone number should contain 10 digits only", Toast.LENGTH_SHORT).show();
        }
     }

    else
    {
        Toast.makeText(MainActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
    }
//  onClick
    }
//  login.onclick
        });
    // for oncreate
    }
    //for main activity
}


