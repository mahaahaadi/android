package com.example.registration2;

import android.app.Activity;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class SharedPreferences extends Activity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        android.content.SharedPreferences sharedPreferences = getSharedPreferences("hiddenfile", Context.MODE_PRIVATE);
        // MODE_private is for hiding the data
        String phone = sharedPreferences.getString("phone","");
        String password = sharedPreferences.getString("password","");

        // if the username and password are not stored in the file
        if ((phone.equals(""))  && (password.equals("")))
        {
            Intent intent = new Intent(SharedPreferences.this,MainActivity.class);
            Toast.makeText(this, "Splash preferences is working......", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }

        else
        {
            Toast.makeText(this, "Splash preferences is working completed successfully", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(SharedPreferences.this,ListViewActivity.class);
            startActivity(intent);
        }
    }

}