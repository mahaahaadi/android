package com.example.login;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

public class SplashScrenActivity extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        SharedPreferences sharedPreferences = getSharedPreferences("logindatasp", Context.MODE_PRIVATE);
        // MODE_private is for hiding the data
        String username = sharedPreferences.getString("username","");

        // if the username and password are not stored in the file
        if (username.equals(""))
        {
            // going back to login page
            Intent intent = new Intent(SplashScrenActivity.this,MainActivity.class);
            startActivity(intent);
        }
        else
        {
            // if right going to the next page
            Intent intent = new Intent(SplashScrenActivity.this,ETActivity.class);
            startActivity(intent);
        }
    }
}
