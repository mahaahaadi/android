package com.example.login;

import android.app.Activity;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;


public class Json_file extends Activity
{

    String[] arrString = new String[5];

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
    super.onCreate(savedInstanceState);


    try
    {
    JSONArray jsonArray = new JSONArray();
    JSONObject jsonObject1 = new JSONObject();
    JSONObject jsonObject2 = new JSONObject();
    JSONObject jsonObject3 = new JSONObject();
    jsonObject1.put("name", "Mahantesh");
    jsonObject1.put("firstname", "address1");
    jsonObject1.put("lastname", "7878454578");
    jsonObject2.put("name", "Vinayak");
    jsonObject2.put("firstname", "address2");
    jsonObject2.put("lastname", "7878454533");
    jsonObject3.put("name", "Ionidea");
    jsonObject3.put("firstname", "address3");
    jsonObject3.put("lastname", "7878454222");

    jsonArray.put(jsonObject1);
    jsonArray.put(jsonObject2);
    jsonArray.put(jsonObject3);

    DatabaseController RegisterDB = new DatabaseController(Json_file.this);

    }
    catch (Exception e)
    {
        e.printStackTrace();
    }

    }
}
