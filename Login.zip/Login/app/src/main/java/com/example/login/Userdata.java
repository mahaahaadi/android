package com.example.login;

public class Userdata
{
    String strUsername,strPhoneNumber,strAddress;


    public void setStrUsername(String strUsername)
    {
        this.strUsername = strUsername;
    }

    public String getStrUsername() {
        return strUsername;
    }

    public void setStrPhoneNumber(String strPhoneNumber)
    {
        this.strPhoneNumber = strPhoneNumber;
    }

    public String getStrPhoneNumber()
    {
        return strPhoneNumber;
    }

    public void setStrAddress(String strAddress)
    {
        this.strAddress = strAddress;
    }

    public String getStrAddress()
    {
        return strAddress;
    }

}