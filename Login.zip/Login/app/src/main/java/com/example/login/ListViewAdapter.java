package com.example.login;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ListViewAdapter extends BaseAdapter {
    JSONArray arrString;
    Context context;
    public ListViewAdapter(JSONArray arrString, Context context) {
        this.arrString = arrString;
        this.context = context;
    }
    @Override
    public int getCount() {
        return arrString.length();
    }

    @Override
    public Object getItem(int position) {
        try {
            return arrString.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView tvAdapter;
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.adapter_listview, parent, false);
            tvAdapter = (TextView) convertView.findViewById(R.id.tvAdapter);
            try {
                JSONObject jsonObject = arrString.getJSONObject(position);
                tvAdapter.setText(jsonObject.getString("name"));
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        return convertView;
    }
}
