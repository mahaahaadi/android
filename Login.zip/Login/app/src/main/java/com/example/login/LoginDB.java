package com.example.login;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;

public class LoginDB extends SQLiteOpenHelper
{
    public static final String DATABASE_NAME = "Login.db";
    public static final int DATABASE_VERSION = 1;
    Context context;

    public LoginDB(Context context)
    {
        super(context,DATABASE_NAME,null,1);
        this.context = context;
    }

    public void onCreate(SQLiteDatabase db)
    {
        String login = "create table login (id  int(5) primary key autoincrement, username text(25),password text(10))";
        db.execSQL(login);
    }


    public void onUpgrade(SQLiteDatabase db,int oldVersion, int newVersion)
    {
        // we can alter the table here
        //  db.execSQL(mysqlQuery);
    }

    public void insertTable(int id, String username, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String str = "insert into login () values(1,'password'','admin',)";
        db.execSQL(str);

        ContentValues inserting = new ContentValues();
        inserting.put("id",1);
        inserting.put("username","admin");
        inserting.put("password","pass");
        db.insert("login",null,inserting);
    }
    public String  getData(int id)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor =  db.rawQuery( "select username,password from login where id='+id+'", null);
        String str = cursor.getString(cursor.getColumnIndex("name"));
        // getColumnIndex is used to get the index of columnName("name");
        return str;
    }


}
