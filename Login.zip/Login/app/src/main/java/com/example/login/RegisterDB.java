package com.example.login;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.database.Cursor;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;


public class RegisterDB extends SQLiteOpenHelper
{
    public static final String DATABASE_NAME = "REGISTER_DB";
    public static final String TABLE_NAME = "REGISTER_TABLE";
    public static final int DATABASE_VERSION = 1;
    Context context;

    public RegisterDB(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }


    public void onCreate(SQLiteDatabase db)
    {
        String creating_table = "CREATE TABLE " + TABLE_NAME +
                " (id int(10) primary key, username varchar(25)," +
                " address varchar(25),phone_number varchar(10))";
        db.execSQL(creating_table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        /*db.execSQL("DROP TABLE "+USERTABLE);
        onCreate(db);*/
    }


  //while inserting data

  public void insertTable(JSONArray jsonArray)
  {
        String sql = "INSERT INTO " + TABLE_NAME + "(username,address,phone_number)" + "VALUES(?,?,?)";
        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        SQLiteStatement stmt = database.compileStatement(sql);

        try
        {
        if (jsonArray.length() > 0)
        {
            for (int i = 0; i < jsonArray.length(); i++)
            {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            stmt.bindString(1, jsonObject.getString("username"));
            stmt.bindString(2, jsonObject.getString("address"));
            stmt.bindString(2, jsonObject.getString("phone_number"));
            stmt.executeInsert();
            stmt.clearBindings();
            }
        }
        }

        catch (Exception e)
        {
            e.printStackTrace();
        }

        database.setTransactionSuccessful();
        database.endTransaction();
        database.close();
    }



    public ArrayList<Userdata> getUserData()
    {
     ArrayList<Userdata> getUserData = new ArrayList<>();
     SQLiteDatabase database = getReadableDatabase();
     String userQuery = "select * from " + TABLE_NAME;

     Cursor cursor = database.rawQuery(userQuery, null);
     if(cursor.moveToFirst())
        {
        do
        {
            Userdata userData = new Userdata();
            userData.setStrAddress(cursor.getString(cursor.getColumnIndex("username")));
            userData.setStrAddress(cursor.getString(cursor.getColumnIndex("address")));
            userData.setStrAddress(cursor.getString(cursor.getColumnIndex("phone_number")));
            getUserData.add(userData);
        }
        while (cursor.moveToNext());
        }
        database.close();
        return getUserData();
    }
}
