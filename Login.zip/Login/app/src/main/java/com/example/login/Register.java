package com.example.login;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Register extends AppCompatActivity {

    EditText username, address, phone_number;
    Button registerbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        username = (EditText) findViewById(R.id.editText1);
        address = (EditText) findViewById(R.id.editText2);
        phone_number = (EditText) findViewById(R.id.editText3);
        registerbtn = (Button) findViewById(R.id.reg_btn);


        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

        String userName = username.getText().toString();
        String Address = address.getText().toString();
        String phoneNumber = phone_number.getText().toString();
        JSONArray jsonArray = new JSONArray();

        JSONObject jsonObject = new JSONObject();

        try
        {
            jsonObject.put("username",userName);
            jsonObject.put("address",Address);
            jsonObject.put("phone_number",phoneNumber);
        }

        catch (JSONException e)
        {
            e.printStackTrace();
        }

        jsonArray.put(jsonObject);
        DatabaseController databaseController = new DatabaseController(Register.this);
        databaseController.insertTable(jsonArray);


        final AlertDialog.Builder alertBox = new AlertDialog.Builder(Register.this);
        alertBox.setMessage("Do you wonna go to login page?");
        alertBox.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
        // action for next page
        Intent main_activity = new Intent(getApplicationContext(), MainActivity.class);
        main_activity.putExtra("username",username.getText().toString());
        main_activity.putExtra("address",address.getText().toString());
        main_activity.putExtra("phone_number",phone_number.getText().toString());

        startActivity(main_activity);
        alertBox.create().dismiss();
            }
        });
        alertBox.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alertBox.create().dismiss();

            }
        });
        alertBox.setNeutralButton("show me later", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alertBox.create().dismiss();
            }
        });
        alertBox.create().show();
            }
        });
    }
}
