package com.example.login;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity
{
    EditText username, password;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        username = (EditText) findViewById(R.id.editText1);
        password = (EditText) findViewById(R.id.editText2);
        btnLogin = (Button) findViewById(R.id.button);

        btnLogin.setOnClickListener(new View.OnClickListener()
        {
        @Override
        public void onClick(View v)
        {

            // TODO Auto-generated method stub
            if (username.getText().toString().trim().length() == 0)
            {
                username.setError("Username is not entered");
                username.requestFocus();
            }

            if (password.getText().toString().trim().length() == 0)
            {
                password.setError("Password is not entered don't use space");
                password.requestFocus();
            }

            else if (username.getText().toString().trim().equals("admin") && password.getText().toString().trim().equals("pass"))
            {
                SharedPreferences sharedPreferences = getSharedPreferences("logindatasp",Context.MODE_PRIVATE);
                // MODE_private is for hiding the data
                // logindatasp is hidden file where the required data like username and passwords are stored.
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("username",username.getText().toString());
                editor.putString("password",password.getText().toString());
                editor.commit();
                //closing syntax

                // action for next page
                Intent ETA_page = new Intent(getApplicationContext(), ETActivity.class);
                ETA_page.putExtra("username",username.getText().toString());
                ETA_page.putExtra("password",password.getText().toString());

                startActivity(ETA_page);
                // action for next page ends
            }

            else
            {
                btnLogin.setError("Password or username isn't correct");
                btnLogin.requestFocus();
            }
            }
            });


            }

}
