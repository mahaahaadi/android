package com.example.login;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity
{
    EditText username, password;
    Button btnLogin;
    DatabaseController databaseController;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        username = (EditText) findViewById(R.id.editText1);
        password = (EditText) findViewById(R.id.editText2);
        btnLogin = (Button) findViewById(R.id.button);
        databaseController = new DatabaseController(MainActivity.this);

        btnLogin.setOnClickListener(new View.OnClickListener()
        {
        @Override
        public void onClick(View v)
        {

        // TODO Auto-generated method stub
        if (username.getText().toString().trim().length() == 0)
        {
            username.setError("Username is not entered");
            username.requestFocus();
        }

        if (password.getText().toString().trim().length() == 0)
        {
            password.setError("Password is not entered don't use space");
            password.requestFocus();
        }

        else if (username.getText().toString().trim().equals("admin") && password.getText().toString().trim().equals("pass"))
        {
        // MODE_private is for hiding the data
        // logindatasp is hidden file where the required data like username and passwords are stored.


        // closing syntax

        // action for next page

            //alert messsage syntax

        final AlertDialog.Builder alertBox = new AlertDialog.Builder(MainActivity.this);
        alertBox.setMessage("Are you sure");
        alertBox.setPositiveButton("Yes",
        new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
        SharedPreferences sharedPreferences = getSharedPreferences("logindatasp",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username",username.getText().toString());
        editor.putString("password",password.getText().toString());
        editor.commit();

        Intent ETA_page = new Intent(getApplicationContext(), ETActivity.class);
        ETA_page.putExtra("username",username.getText().toString());
        ETA_page.putExtra("password",password.getText().toString());
        startActivity(ETA_page);

        alertBox.create().dismiss();
            }
        });
        alertBox.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alertBox.create().dismiss();

            }
        });
        alertBox.setNeutralButton("show me later", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alertBox.create().dismiss();

            }
        });

        alertBox.create().show();



        // action for next page ends
        }

        else
        {
            btnLogin.setError("Password or username isn't correct");
            btnLogin.requestFocus();
        }
        }
        });


        }

    }
