package com.example.login;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class LVActivity extends Activity {
    ListView lvArrString;
    String[] arrString = new String[5];
    ListViewAdapter listViewAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lv);
        lvArrString = (ListView) findViewById(R.id.lvArrString);
        try {
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject1 = new JSONObject();
            JSONObject jsonObject2 = new JSONObject();
            JSONObject jsonObject3 = new JSONObject();
            jsonObject1.put("name", "mahantesh");
            jsonObject1.put("firstname", "dsfsdf");
            jsonObject1.put("lastname", "mahantefdgsh");
            jsonObject2.put("name", "vinayak");
            jsonObject2.put("firstname", "dsfsdf");
            jsonObject2.put("lastname", "mahantefdgsh");
            jsonObject3.put("name", "mahansfsdtesh");
            jsonObject3.put("firstname", "dsfsdf");
            jsonObject3.put("lastname", "mahantefdgsh");
            jsonArray.put(jsonObject1);
            jsonArray.put(jsonObject2);
            jsonArray.put(jsonObject3);
            listViewAdapter = new ListViewAdapter(jsonArray,LVActivity.this);
            lvArrString.setAdapter(listViewAdapter);

        } catch (Exception e) {
            e.printStackTrace();
        }



    }
}
