package com.example.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ETActivity extends Activity {
    EditText editText;
    private Spinner spinner1, spinner2;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_et);


        Bundle bundle = getIntent().getExtras();

        String username = bundle.getString("username");
        TextView textView = (TextView) findViewById(R.id.TextView1);
        textView.setText("You have logged in through the name : " + username);

        String password = bundle.getString("password");
        TextView textViewpass = findViewById(R.id.TextView2);
        textViewpass.setText("with the password " + password);


        addItemsOnSpinner2();
        addListenerOnButton();
        addListenerOnSpinnerItemSelection();
    }

    // add items into spinner dynamically
    public void addItemsOnSpinner2() {

        spinner2 = (Spinner) findViewById(R.id.spinner2);
        List<String> list = new ArrayList<String>();
        list.add("one");
        list.add("two");
        list.add("three");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter);
    }

    public void addListenerOnSpinnerItemSelection() {
        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner1.setOnItemSelectedListener(new SDFAdapter());
    }

    // get the selected dropdown list value
    public void addListenerOnButton() {

        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {

            Toast.makeText(com.example.login.ETActivity.this,
                    "OnClickListener : " +
                            "\nSpinner 1 : " + String.valueOf(spinner1.getSelectedItem()) +
                            "\nSpinner 2 : " + String.valueOf(spinner2.getSelectedItem()),
                    Toast.LENGTH_SHORT).show();

            Intent SDFAdapter = new Intent(getApplicationContext(), SDFAdapter.class);
            SDFAdapter.putExtra("spinner",(Bundle) spinner1.getSelectedItem());
            SDFAdapter.putExtra("spinner",(Bundle) spinner2.getSelectedItem());

            startActivity(SDFAdapter);
        }

        });
    }
}