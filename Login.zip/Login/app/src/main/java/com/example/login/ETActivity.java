package com.example.login;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;
import java.util.List;

public class ETActivity extends Activity {
    EditText editText;
    private Spinner spinner1, spinner2;
    private Button btnSubmit;
    DatabaseController databaseController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_et);
        /*databaseController = new DatabaseController(ETActivity.this);
        String data = databaseController.getData(1);*/


       /* Bundle bundle = getIntent().getExtras();

        String username = bundle.getString("username");*/
        SharedPreferences sharedPreferences = getSharedPreferences("logindatasp", Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("username","");
        TextView textView = (TextView) findViewById(R.id.TextView1);
        textView.setText("You have logged in through the name : " + username);
        String password = sharedPreferences.getString("password","");
        TextView textViewpass = findViewById(R.id.TextView2);
        textViewpass.setText("with the password " + password);


        addItemsOnSpinner2();
        addListenerOnButton();
        addListenerOnSpinnerItemSelection();
    }

    // add items into spinner dynamically
    public void addItemsOnSpinner2() {

        spinner2 = (Spinner) findViewById(R.id.spinner2);
        List<String> list = new ArrayList<String>();
        list.add("one");
        list.add("two");
        list.add("three");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter);
    }

    public void addListenerOnSpinnerItemSelection() {
        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner1.setOnItemSelectedListener(new SDFAdapter());
    }

    // get the selected dropdown list value
    public void addListenerOnButton() {

        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v)
        {

            Toast.makeText(com.example.login.ETActivity.this,
                    "OnClickListener : " +
                            "\nSpinner 1 : " + String.valueOf(spinner1.getSelectedItem()) +
                            "\nSpinner 2 : " + String.valueOf(spinner2.getSelectedItem()),
                    Toast.LENGTH_SHORT).show();


            //alert dialog syntax starts
            final AlertDialog.Builder alertBox = new AlertDialog.Builder(ETActivity.this); // ETActivity is current page
            alertBox.setMessage("This is going to take you to login page");


            alertBox.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences sharedPreferences = getSharedPreferences("logindatasp",Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
//                  editor.putString("username",username.getText().toString());
//                  editor.putString("password",password.getText().toString());
                    editor.commit();
                    Intent MainActivity = new Intent(getApplicationContext(), LVActivity.class);
//                    MainActivity.putExtra("username",username.getText().toString());
//                    MainActivity.putExtra("password",password.getText().toString());
                    startActivity(MainActivity);
                    alertBox.create().dismiss();
                }
            });

            alertBox.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertBox.create().dismiss();

                }
            });

            alertBox.create().show();

            //alert dialog syntax ends



        Intent SDFAdapter = new Intent(getApplicationContext(), MainActivity.class);
           // SDFAdapter.putExtra("spinner",spi);
            SharedPreferences sharedPreferences = getSharedPreferences("logindatasp", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor= sharedPreferences.edit();
            editor.clear();
            editor.commit();
//            startActivity(SDFAdapter);
        }

        });
    }
}