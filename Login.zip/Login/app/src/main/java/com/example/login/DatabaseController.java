package com.example.login;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class DatabaseController extends SQLiteOpenHelper
{
    public static final String DATABASE_NAME = "ems.db";
    public static final String USERTABLE = "user_table";
    public static final int DATABASE_VERSION = 1;
    Context context;

    public DatabaseController(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }


    public void onCreate(SQLiteDatabase db)
    {
        String user_table = "CREATE TABLE " + USERTABLE + " (id integer primary key, username text,phonenumber text,address text)";
        db.execSQL(user_table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE "+USERTABLE);
        onCreate(db);
    }

    public void insertTable(JSONArray jsonArray)
    {
        String sql = "INSERT INTO " + USERTABLE + "(username, phonenumber , address) VALUES (?, ?, ?);";

        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        SQLiteStatement stmt = database.compileStatement(sql);
        try
        {
            if (jsonArray.length() > 0)
        {
        for (int i = 0; i < jsonArray.length(); i++)
        {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            stmt.bindString(1, jsonObject.getString("username"));
            stmt.bindString(2, jsonObject.getString("phone_number"));
            stmt.bindString(3, jsonObject.getString("address"));
            stmt.executeInsert();
            stmt.clearBindings();
        }
        }
        }

        catch (Exception e)
        {
            e.printStackTrace();
        }

        database.setTransactionSuccessful();
        database.endTransaction();
        database.close();
    }

    public ArrayList<Userdata> getUserdata ()
    {
    ArrayList<Userdata> getUserData = new ArrayList<>();
    SQLiteDatabase database = getReadableDatabase();
    String userQuery = "SELECT * FROM "+USERTABLE;
    Cursor cursor = database.rawQuery(userQuery, null);

    if (cursor.moveToFirst())
    {
    do
    {
        Userdata userData = new Userdata();
        userData.setStrUsername(cursor.getString(cursor.getColumnIndex("username")));
        userData.setStrPhoneNumber(cursor.getString(cursor.getColumnIndex("phonenumber")));
        userData.setStrAddress(cursor.getString(cursor.getColumnIndex("address")));
        getUserData.add(userData);
    }

    while (cursor.moveToNext());

    }
    database.close();
    return getUserData;
    }
}