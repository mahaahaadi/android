package com.example.registration;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;


public class Register_Database extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "register";
    public final String TABLE_NAME = "register_table";
    private static final int DATABASE_VERSION = 1;
    Context context;


    public Register_Database(Context context)
    {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String create_table = "create table IF NOT EXISTS " + TABLE_NAME + "(id int(10) primary key, username text, address text, phonenumber text);";
        db.execSQL(create_table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        /*db.execSQL("DROP TABLE "+TABLE_NAME);
        onCreate(db);*/
    }

    public void insert(JSONArray jsonArray)
    {
        String sql = "insert into " + TABLE_NAME +"(username,address,phonenumber) values(?,?,?);";

        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();

        SQLiteStatement SQLsmt = database.compileStatement(sql);
        try
        {
        if(jsonArray.length() > 0)
        {
          for(int i=0; i<jsonArray.length(); i++)
          {
          JSONObject jsonObject = jsonArray.getJSONObject(i);
          SQLsmt.bindString(1, jsonObject.getString("username"));
          SQLsmt.bindString(2, jsonObject.getString("address"));
          SQLsmt.bindString(3, jsonObject.getString("phonenumber"));
          SQLsmt.executeInsert();
          SQLsmt.clearBindings();
          }
        }
        }
        catch(Exception e)
        {

        }

        database.setTransactionSuccessful();
        database.endTransaction();
        database.close();
    }

    // **************
    public ArrayList<Userdata> getUserdata()
    {
    ArrayList<Userdata> getUserData = new ArrayList<>();
    SQLiteDatabase database = getReadableDatabase();
    String userQuery = "SELECT * FROM "+ TABLE_NAME;
    Cursor cursor = database.rawQuery(userQuery, null);

    if (cursor.moveToFirst())
    {
    do
    {
    Userdata userData = new Userdata();
    userData.setusername(cursor.getString(cursor.getColumnIndex("username")));
    userData.setaddress(cursor.getString(cursor.getColumnIndex("address")));
    userData.setphonenumber(cursor.getString(cursor.getColumnIndex("phonenumber")));
    getUserData.add(userData);
    }

    while (cursor.moveToNext());
    }
    database.close();
    return getUserData;
    }

}