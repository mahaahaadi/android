package com.example.registration;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity
{
    String username_str, address_str;
    String phonenumber_str;

    EditText username, address, phonenumber;
    Button regbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username    = (EditText) findViewById(R.id.username);
        address     = (EditText) findViewById(R.id.address);
        phonenumber = (EditText) findViewById(R.id.phonenumber);
        regbtn      = (Button) findViewById(R.id.regbtn);

        regbtn.setOnClickListener(new View.OnClickListener()
        {
        @Override
        public void onClick(View v)
        {
        // TODO Auto-generated method stub

        username_str = username.getText().toString();
        address_str = address.getText().toString();
        phonenumber_str = phonenumber.getText().toString();


        if ((!username_str.equals("")) && (!address_str.equals("")) && (!phonenumber_str.equals("")))
        {
            if(phonenumber_str.length() != 10)
            {
                Toast.makeText(MainActivity.this, "enter only 10 digit mobile number", Toast.LENGTH_SHORT).show();
            }

            else if(address_str.length() < 10)
            {
                Toast.makeText(MainActivity.this, "address is too short", Toast.LENGTH_SHORT).show();
            }
            else {

                try {
                    JSONArray jsonArray = new JSONArray();
                    JSONObject jsonObject1 = new JSONObject();

                    jsonObject1.put("username", username_str);
                    jsonObject1.put("address", address_str);
                    jsonObject1.put("phonenumber", phonenumber_str);

                    jsonArray.put(jsonObject1);
                    Register_Database insert_data = new Register_Database(MainActivity.this);
                    insert_data.insert(jsonArray);
                }


        catch (Exception e)
        {
            e.printStackTrace();
        }
        Toast.makeText(MainActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
        Intent LVActivity = new Intent(getApplicationContext(), LVActivity.class);
        startActivity(LVActivity);
    }
        }

    else
    {
        Toast.makeText(MainActivity.this, "All the fields are required!", Toast.LENGTH_SHORT).show();
    }

    }
    });
    }
}