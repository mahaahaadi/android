package com.example.registration;

public class Userdata
{
String strusername, straddress,strphonenumber;

    // for username
    public void setusername(String strusername)
    {
        this.strusername = strusername;
    }

    public String getusername()
    {
        return strusername;
    }

    public void setaddress(String straddress)
    {
        this.straddress = straddress;
    }

    // for address
    public String getaddress()
    {
        return straddress;
    }

    // for phonenumber
    public void setphonenumber(String strphonenumber)
    {
        this.strphonenumber = strphonenumber;
    }
    public String getphonenumber()
    {
        return strphonenumber;
    }

}