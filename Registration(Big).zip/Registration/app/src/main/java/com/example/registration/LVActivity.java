package com.example.registration;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;

public class LVActivity extends Activity
{
    ListView listView;
    ListViewAdapter listViewAdapter;

    protected void onCreate(Bundle savedInstanceState)
    {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.listview);

    listView = (ListView) findViewById(R.id.lvAdapter1);

    // *************

    Register_Database databaseController = new Register_Database(LVActivity.this);
    ArrayList<Userdata> userDataList = databaseController.getUserdata();

      listViewAdapter = new ListViewAdapter(userDataList,LVActivity.this);
      listView.setAdapter(listViewAdapter);

    }

}