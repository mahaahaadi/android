package com.example.login2;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {

    EditText EmailAdd;
    EditText Password;
    Button Login;
    Button NewUser;
    private SQLiteAdapter db;
    int attempts = 3;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        //addListenerOnButton();

        //Button mNewUser = (Button)findViewById(R.id.btnLogMain);
        //mNewUser.setOnClickListener(this);

        EmailAdd = (EditText) findViewById(R.id.email);
        Password = (EditText) findViewById(R.id.password);

        Login = (Button) findViewById(R.id.btnLogMain);
        Login.setOnClickListener(buttonLoginOnClickListener);
        NewUser = (Button) findViewById(R.id.btnNewUser);
        //NewUser.setOnClickListener(buttonNewUserOnClickListener); //<<<<IGNORED
    }

    Button.OnClickListener buttonLoginOnClickListener
            = new Button.OnClickListener() {
        @Override
        public void onClick(View arg0) {
            //SQLiteAdapter db = new SQLiteAdapter (LoginActivity.this );
            SQLiteDatabase db = new SQLiteAdapter(LoginActivity.this).openToWrite();
            String email = EmailAdd.getText().toString();
            String password = Password.getText().toString();

            //Cursor c = db.rawQuery("SELECT email FROM MY_USERS_TABLE WHERE email= ? AND password=?", new String[]{email, password});
            Cursor c = db.query(SQLiteAdapter.MYDATABASE_TABLE,
                    new String[]{SQLiteAdapter.KEY_EMAIL},
                    SQLiteAdapter.KEY_EMAIL + "=? AND " +SQLiteAdapter.KEY_PASSWORD + "=?",
                    new String[]{email,password},
                    null,null,null
            );
            if (c.moveToFirst()) {
                Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_SHORT).show();
                // NO
                //Intent main = new Intent(LoginActivity.this, MainMenuActivity.class);
                //startActivity(main);
                setResult(Activity.RESULT_OK);
                finish(); //<<<< go back
            } else {
                Toast.makeText(getApplicationContext(), "Failed..\nTry Again", Toast.LENGTH_SHORT).show();
                if (--attempts <= 0) {
                    setResult(Activity.RESULT_CANCELED);
                    finish();
                }
            }
        }
    };
}