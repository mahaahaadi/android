package com.example.login2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


class MainMenuActivity extends AppCompatActivity {
    static boolean loggedin = false;
    SQLiteAdapter mAdapter;
    int requestcode = 100;
    Button menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        menu = (Button) this.findViewById(R.id.mymenu);

        mAdapter = new SQLiteAdapter(this);
        mAdapter.insert("Fred","Fred@email.com","password");
        if (!loggedin) {
            Intent intent = new Intent(this,LoginActivity.class);
            startActivityForResult(intent,requestcode);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    protected void onActivityResult(int reqcode, int reqresult, Intent intent) {
        super.onActivityResult(reqcode, reqresult, intent);
        if (reqcode == requestcode && reqresult == Activity.RESULT_OK) {
            loggedin = true;
            menu.setVisibility(View.VISIBLE);

        } else {
            loggedin = false;
            Toast.makeText(this, "You are now Logged In", Toast.LENGTH_SHORT).show();
        }
    }
}
