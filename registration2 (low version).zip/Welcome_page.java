package com.example.registration2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Welcome_page extends Activity
{
    String hello_message_str;
    TextView hello_message;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_page);

        hello_message  = (TextView) findViewById(R.id.hello_message);
        hello_message.setText("Hello this is your welcome page.");

    }
}
