package com.example.registration2;

import com.google.gson.JsonArray;
import com.google.gson.annotations.SerializedName;

public class ResponseData
{
    @SerializedName("response")
    private String response;

    @SerializedName("data")
    private JsonArray data;

    public String getResponse()
    {
        return response;
    }
    public JsonArray getData()
    {
        return data;
    }
}
