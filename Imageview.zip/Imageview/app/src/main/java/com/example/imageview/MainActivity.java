package com.example.imageview;

    import android.support.v7.app.AppCompatActivity;
    import android.os.Bundle;

    import android.view.View;
    import android.widget.ImageView;
    import android.widget.Toast;

public class MainActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        ImageView one = (ImageView) findViewById(R.id.one);//get the id of first image view
//        ImageView two = (ImageView) findViewById(R.id.two);//get the id of second image view
//        ImageView sharadamaa = (ImageView) findViewById(R.id.sharadamaa);//get the id of second image view
//        ImageView sudha = (ImageView) findViewById(R.id.sudha);//get the id of second image view

//        one.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(getApplicationContext(), "one", Toast.LENGTH_LONG).show();//display the text on image click event
//            }
//        });
//
//        two.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(getApplicationContext(), "one", Toast.LENGTH_LONG).show();//display the text on image click event
//            }
//        });
//
//        sharadamaa.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(getApplicationContext(), "one", Toast.LENGTH_LONG).show();//display the text on image click event
//            }
//        });
//
//        sudha.setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(getApplicationContext(), "one", Toast.LENGTH_LONG).show();//display the text on image click event
//            }
//        });

    }
}