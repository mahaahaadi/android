package com.example.firebasedemo;


import android.util.Log;
import android.view.View;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.annotation.NonNull;
import android.widget.ArrayAdapter;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirestoreRegistrar;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;


public class MainActivity extends AppCompatActivity {

    private Button logout,add;
    private EditText edit;
    private ListView listview;
    private TextView textview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logout = findViewById(R.id.logout);
        edit = findViewById(R.id.edit);
        add = findViewById(R.id.add);
        listview = findViewById(R.id.listview);
        textview = findViewById(R.id.textview);

        logout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(MainActivity.this, "Log out!", Toast.LENGTH_SHORT).show();
                 startActivity(new Intent(MainActivity.this, StartActivity.class));
            }
        });

//        HashMap <String,Object> map = new HashMap<>();
//        map.put("mail","mahantesh@gmail.commm");
//        map.put("password","1234567890");
//        FirebaseDatabase.getInstance().getReference().child("programming language").child("MultipleValues").updateChildren(map);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txt_name = edit.getText().toString();
                if(txt_name.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "no name entered", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    FirebaseDatabase.getInstance().getReference().child("information").child("Name").setValue(txt_name);
                    // out of syllabus ;)
                    Toast.makeText(MainActivity.this, "Name added successfully!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        final ArrayList<String> list = new ArrayList<>();
        final ArrayAdapter adapter = new ArrayAdapter<String>(this,R.layout.list_item, list);
        listview.setAdapter(adapter);

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("branch1");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();
                for(DataSnapshot snapshot : dataSnapshot.getChildren())
                {
                    Information info = snapshot.getValue(Information.class);
                    String txt = info.getName() + " : "+info.getEmail();
                            list.add(txt);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

//         cloud firebase part 1
//        DocumentReference ref = FirebaseFirestore.getInstance().collection("cities").document("BJ");
//        ref.update("name ","IR");


//
//        DocumentReference ref = FirebaseFirestore.getInstance().collection("cities").document("DC");
//        ref.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
//            @Override
//            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
//                if(task.isSuccessful())
//                {
//                            DocumentSnapshot doc = task.getResult();
//                            if(doc.exists())
//                            {
//                                String data = doc.getData().toString();
//                                    Log.d("Document",data);
//                                    textview.setText(data);
//                            }
//                            else
//                            {
//                                Log.d("Document","no data");
//                            }
//                }
//            }
//        });



// cloud firebase part 2
//        FirebaseFirestore.getInstance().collection("cities").whereEqualTo("capital",true)
//                .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
//            @Override
//            public void onComplete(@NonNull Task<QuerySnapshot> task) {
//                if(task.isSuccessful())
//                {
//                        for(QueryDocumentSnapshot doc: task.getResult())
//                        {
//                                    textview.setText(doc.getId() + "=> " + doc.getData());
//                        }
//                }
//            }
//        });



    }
}