package com.example.registration2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class Adapter extends BaseAdapter
{
    ArrayList<Userdata> getUserData;
    Context context;

    public Adapter(ArrayList<Userdata> getUserData, Context context)
    {
        this.getUserData = getUserData;
        this.context = context;
    }

    @Override
    public int getCount() {
        return getUserData.size();
    }

    @Override
    public Object getItem(int position)
    {
        return getUserData.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        TextView firstname,lastname,phonenumber,email,password;

        if (convertView == null)
        {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.adapter_design, parent, false);

            firstname    = (TextView) convertView.findViewById(R.id.firstname);
            lastname     = (TextView) convertView.findViewById(R.id.lastname);
            phonenumber  = (TextView) convertView.findViewById(R.id.phonenumber);
            email        = (TextView) convertView.findViewById(R.id.email);
            password     = (TextView) convertView.findViewById(R.id.password);

            firstname.setText(getUserData.get(position).getstrfirstname());
            lastname.setText(getUserData.get(position).getstrlastname());
            phonenumber.setText(getUserData.get(position).getstrphonenumber());
            email.setText(getUserData.get(position).getstremail());
            password.setText(getUserData.get(position).getstrpassword());
        }
        return convertView;
    }
}