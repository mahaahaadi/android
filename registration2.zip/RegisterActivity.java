package com.example.registration2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends Activity
{

    EditText first_name, last_name, phone_number, email, password;
    Button register;
    String first_name_str, last_name_str, phone_number_str, email_str, password_str;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        first_name = (EditText) findViewById(R.id.register_firstname);
        last_name = (EditText) findViewById(R.id.register_lastname);
        phone_number = (EditText) findViewById(R.id.register_phonenumber);
        email = (EditText) findViewById(R.id.register_email);
        password = (EditText) findViewById(R.id.register_password);
        register = (Button) findViewById(R.id.register_regbtn);

        register.setOnClickListener(new View.OnClickListener() {
            @Override


                public void onClick(View v)
                {
                    first_name_str = first_name.getText().toString();
                    last_name_str = last_name.getText().toString();
                    phone_number_str = phone_number.getText().toString();
                    email_str = email.getText().toString();
                    password_str = password.getText().toString();

                    try
                    {
                        JSONArray jsonArray = new JSONArray();
                        JSONObject jsonObject = new JSONObject();

                        jsonObject.put("firstname", first_name_str);
                        jsonObject.put("lastname", last_name_str);
                        jsonObject.put("phonenumber", phone_number_str);
                        jsonObject.put("email", email_str);
                        jsonObject.put("password", password_str);

                        jsonArray.put(jsonObject);
                        Database_register insert_data = new Database_register(RegisterActivity.this);
                        ///insert_data.insert(jsonArray);
                    }

                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                    Toast.makeText(RegisterActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();


            Intent target = new Intent(getApplicationContext(),ListViewActivity.class);
            startActivity(target);
                }
            });
        }

}