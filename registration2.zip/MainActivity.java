package com.example.registration2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    String phone_str,password_str;

    EditText phone,password;
    TextView newuser;
    Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);



        phone    = (EditText) findViewById(R.id.login_phonenumber);
        password = (EditText) findViewById(R.id.login_password);
        newuser  = (TextView) findViewById(R.id.login_newuser);
        login    = (Button)   findViewById(R.id.login_regbtn);

        newuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent register_page = new Intent(getApplicationContext(),RegisterActivity.class);
                startActivity(register_page);
            }
        }

        );



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                phone_str = phone.getText().toString();
                password_str = password.getText().toString();


                if ((!phone_str.equals("")) && (!password_str.equals(""))) {
                    if (phone_str.length() != 10) {
                        Toast.makeText(MainActivity.this, "enter only 10 digit mobile number", Toast.LENGTH_SHORT).show();
                    }

//        else if(password_str.length() < 8)
//        {
//            Toast.makeText(MainActivity.this, "address is too short", Toast.LENGTH_SHORT).show();
//        }

                    else {

        /*try
        {
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject1 = new JSONObject();

            jsonObject1.put("phone_number", phone_str);
            jsonObject1.put("password", password_str)*/
                        ;


          /*  jsonArray.put(jsonObject1);
            Database_login insert_data = new Database_login(MainActivity.this);
            insert_data.insert(jsonArray);*/

                    }


//            catch (Exception e)
//            {
//                e.printStackTrace();
//            }

//            Toast.makeText(MainActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
//            Intent LVActivity = new Intent(getApplicationContext(), LVActivity.class);
//            startActivity(LVActivity);
                }
            }

               /* else
                {
                    Toast.makeText(MainActivity.this, "All the fields are required!", Toast.LENGTH_SHORT).show();
                }*/


        });
    }
}
