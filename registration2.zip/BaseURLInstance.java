package com.example.registration2;
import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BaseURLInstance {
    private static Retrofit retrofit;
    public static String BASE_URL;

    public static Retrofit getRetrofitInstance(Context context) {
        try {

            BASE_URL = "http://10.0.2.2/ionemsmobile/index.php/";
            if (retrofit == null) {
                Gson gson = new GsonBuilder()
                        .setLenient()
                        .create();
                    final OkHttpClient okHttpClient = new OkHttpClient.Builder()
                            .connectTimeout(180, TimeUnit.SECONDS)
                            .writeTimeout(180, TimeUnit.SECONDS)
                            .readTimeout(100, TimeUnit.SECONDS)
                            .build();
                    retrofit = new Retrofit.Builder()
                            .baseUrl(BASE_URL)
                            .addConverterFactory(GsonConverterFactory.create(gson))
                            .client(okHttpClient)
                            .build();
                }
            }
         catch (Exception e) {
            e.printStackTrace();
        }
        return retrofit;
    }
}