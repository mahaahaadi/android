package com.example.registration2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import com.google.gson.JsonArray;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListViewActivity extends Activity
{
    ListView listView;
    Adapter listViewAdapter;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listviewadapter);

        listView = (ListView) findViewById(R.id.lvAdapter1);

        //Base URL implementation
        ControllerFunctions service = BaseURLInstance.getRetrofitInstance(ListViewActivity.this).create(ControllerFunctions.class);
        //post parameters
        HashMap<String, String> params = new HashMap<>();
        //params.put("phone","2147483647");

        //calling controller's functions
        Call<List<ResponseData>> call = service.getUserDetails(params);

        call.enqueue(new Callback<List<ResponseData>>() {
            @Override
            public void onResponse(Call<List<ResponseData>> call, Response<List<ResponseData>> response)
            {
                //getting server response
                if (response.isSuccessful()) {
                    //check response variable is true or false
                    String strResponse = response.body().get(0).getResponse();
                    if (strResponse.equals("true"))
                    {

                        // get data (JSON)
                        JsonArray jsonData = response.body().get(0).getData();

                        //inserting of json data to local database
                        Database_register database_register = new Database_register(ListViewActivity.this);
                        database_register.delete_data();
                        database_register.insert(jsonData);

                        //get Data from local android database and set it listview
                        ArrayList<Userdata> userDataList = database_register.getUserdata();
                        listViewAdapter = new Adapter(userDataList,ListViewActivity.this);
                        listView.setAdapter(listViewAdapter);
                    }
                }

            }

            @Override
            public void onFailure(Call<List<ResponseData>> call, Throwable t) {
            }
        });

    }

}