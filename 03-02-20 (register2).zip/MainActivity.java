package com.example.registration2;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import retrofit2.Response;
import retrofit2.Callback;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class MainActivity extends AppCompatActivity
{
    String phone_str,password_str;

    EditText phone,password;
    TextView newuser;
    Button login;

    private Pattern pattern;
    private Matcher matcher;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        phone    = (EditText) findViewById(R.id.login_phonenumber);
        password = (EditText) findViewById(R.id.login_password);
        newuser  = (TextView) findViewById(R.id.login_newuser);
        login    = (Button)   findViewById(R.id.login_regbtn);

        phone_str = phone.getText().toString();
        password_str = password.getText().toString();
        private static final String PASSWORD_PATTERN;

        newuser.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent register_page = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(register_page);
            }
        }

        );

        login.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // TODO Auto-generated method stub

                phone_str = phone.getText().toString();
                password_str = password.getText().toString();


                if ((!phone_str.equals("")) && (!password_str.equals("")))
                {

                    ////////////////

                    if (phone_str.length() == 10) {

//
//
//                        PASSWORD_PATTERN =
//                                "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
//
//      public PasswordValidator(){
//                            pattern = Pattern.compile(PASSWORD_PATTERN);
//                        }
//
//                        /**
//                         * Validate password with regular expression
//                         * @param password password for validation
//                         * @return true valid password, false invalid password
//                         */
//                        public boolean validate(final String password){
//
//                            matcher = pattern.matcher(password);
//                            return matcher.matches();
//
//                        }
//                        



                            //Base URL implementation
                            ControllerFunctions service = BaseURLInstance.getRetrofitInstance(MainActivity.this).create(ControllerFunctions.class);

                            //post parameters
                            HashMap<String, String> params = new HashMap<>();
                            params.put("phone",phone_str);
                            params.put("password",password_str);

                            //calling controller's functions
                            Call<List<ResponseData>> call = service.checkLogin(params);

                            call.enqueue(new Callback<List<ResponseData>>()
                            {
                                @Override
                                public void onResponse(Call<List<ResponseData>> call, Response<List<ResponseData>> response)
                                {
                                    //getting server response
                                    if (response.isSuccessful())
                                    {
                                        //check response variable is true or false
                                        String strResponse = response.body().get(0).getResponse();
                                        if (strResponse.equals("true"))
                                        {
                                            Intent target = new Intent(getApplicationContext(),ListViewActivity.class);
                                            startActivity(target);
                                        }
                                        else
                                        {
                                            Toast.makeText(MainActivity.this, "error in response", Toast.LENGTH_SHORT).show();
                                        }

                                    }

                                }

                                @Override
                                public void onFailure(Call<List<ResponseData>> call, Throwable t) {
                                    Toast.makeText(MainActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                                }
                            });

                        }// for password pattern

                        else
                        {
                            Toast.makeText(MainActivity.this, "pattern didn't match", Toast.LENGTH_SHORT).show();
                        }

                    }
                    else
                    {
                        Toast.makeText(MainActivity.this, "Enter only 10 digit phone number", Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    Toast.makeText(MainActivity.this, "All the fields are required", Toast.LENGTH_SHORT).show();
                }


                      }


            });

        }
    }

